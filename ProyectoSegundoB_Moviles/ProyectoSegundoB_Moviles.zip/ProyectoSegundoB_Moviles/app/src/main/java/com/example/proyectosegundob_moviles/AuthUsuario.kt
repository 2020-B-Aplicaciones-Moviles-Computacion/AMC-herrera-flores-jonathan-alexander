package com.example.proyectosegundob_moviles

class AuthUsuario {
    companion object {
        var usuario: UsuarioLocal? = null
    }
}