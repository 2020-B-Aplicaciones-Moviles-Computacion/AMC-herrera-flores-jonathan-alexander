package com.example.proyectosegundob_moviles

class UsuarioLocal(
    val uid: String,
    val email: String,
    var nombre: String?,
    var identificacion: String?,
    var pais: String?,
    var fechaNacimiento: String?,
    var fechaRegistro: String,
    var ingresosMes: String?,
    var egresosMes: String?
) {

}