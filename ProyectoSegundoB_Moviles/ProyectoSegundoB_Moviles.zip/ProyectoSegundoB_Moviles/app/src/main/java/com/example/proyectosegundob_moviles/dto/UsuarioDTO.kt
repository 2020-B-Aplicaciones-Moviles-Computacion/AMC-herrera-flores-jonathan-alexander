package com.example.proyectosegundob_moviles.dto

data class UsuarioDTO(
    var nombre: String = "",
    var identificacion: String = "",
    var pais: String = "",
    var fechaNacimiento: String = "",
    var fechaRegistro: String = "",
    var ingresosMes: String = "",
    var egresosMes: String = ""
) {
}