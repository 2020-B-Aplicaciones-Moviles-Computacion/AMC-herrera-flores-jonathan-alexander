package com.example.proyectosegundob_moviles

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.jjoe64.graphview.DefaultLabelFormatter
import com.jjoe64.graphview.GraphView
import com.jjoe64.graphview.GridLabelRenderer
import com.jjoe64.graphview.LegendRenderer
import com.jjoe64.graphview.series.*
import java.text.SimpleDateFormat
import java.util.*


class Dashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        crearBarra()
        setearBalance()
        setearMetas()

        findViewById<ImageView>(R.id.btn_masBalance)
            .setOnClickListener {
                startActivity(
                    Intent(
                        this,
                        IngresoEgreso::class.java
                    )
                )
            }

        findViewById<ImageView>(R.id.btn_masMetas)
            .setOnClickListener{
                startActivity(
                    Intent(
                        this,
                        Metas::class.java
                    )
                )
            }
    }

    fun setearBalance() {
        val calendar: Calendar = Calendar.getInstance()
        val sdf = SimpleDateFormat("MM/yyyy", Locale.ENGLISH);
        calendar.time = sdf.parse("01/1994")

        val d1: Date = calendar.time
        calendar.add(Calendar.MONTH, 1)
        val d2: Date = calendar.time
        calendar.add(Calendar.MONTH, 1)
        val d3: Date = calendar.time
        calendar.add(Calendar.MONTH, 1)
        val d4: Date = calendar.time
        calendar.add(Calendar.MONTH, 1)
        val d5: Date = calendar.time
        calendar.add(Calendar.MONTH, 1)
        val d6: Date = calendar.time

        val grBalance = findViewById<View>(R.id.gr_balance) as GraphView
        val points = arrayOf(
            DataPoint(d1.time.toDouble(), 1.0),
            DataPoint(d2.time.toDouble(), 5.0),
            DataPoint(d3.time.toDouble(), 3.0),
            DataPoint(d4.time.toDouble(), 1.0),
            DataPoint(d5.time.toDouble(), 1.0),
            DataPoint(d6.time.toDouble(), 1.0)
        )

        val seBalance = LineGraphSeries(
            points
        )

        seBalance.isDrawBackground = true

        seBalance.setOnDataPointTapListener { _, dataPoint ->
            var newValue = Date(dataPoint.x.toLong())
            val retorno = (newValue.month + 1).toString() + "/" + (newValue.year + 1900).toString()
            val prompt = Toast.makeText(
                this,
                "Date: $retorno, Balance: ${dataPoint.y}",
                Toast.LENGTH_SHORT
            )
            prompt.setGravity(Gravity.CENTER_HORIZONTAL, grBalance.x.toInt(), grBalance.y.toInt())
            prompt.show();
        }

        grBalance.addSeries(
            seBalance
        )

        val seBalancePoints = PointsGraphSeries(
            points
        )

        seBalancePoints.size = 15.toFloat()

        grBalance.addSeries(
            seBalancePoints
        )

        grBalance.gridLabelRenderer.gridColor = Color.parseColor("#A9B1C5")
        grBalance.gridLabelRenderer.gridStyle = GridLabelRenderer.GridStyle.BOTH

        grBalance.gridLabelRenderer.numHorizontalLabels = 2

        grBalance.viewport.setMinX(d1.time.toDouble());
        grBalance.viewport.setMaxX(d6.time.toDouble());
        grBalance.viewport.isXAxisBoundsManual = true;

        grBalance.gridLabelRenderer.setHumanRounding(false);

        grBalance.gridLabelRenderer.labelFormatter = object : DefaultLabelFormatter() {
            override fun formatLabel(value: Double, isValueX: Boolean): String {
                return if (isValueX) {
                    var newValue = Date(value.toLong())
                    val retorno =
                        (newValue.month + 1).toString() + "/" + (newValue.year + 1900).toString()
                    retorno
                } else {
                    super.formatLabel(value, isValueX)
                }
            }
        }
    }

    fun setearMetas() {
        val grMetas = findViewById<View>(R.id.gr_metas) as GraphView

        val metasPoint = arrayOf(
            Pair(10.0, "car"),
            Pair(25.0, "home"),
            Pair(50.0, "scholarship"),
            Pair(46.0, "debt"),
            Pair(78.0, "bank")
        )

        for ((i, meta) in metasPoint.withIndex()) {
            val seMetas = BarGraphSeries(
                arrayOf(DataPoint((i + 1).toDouble(), meta.first)),
            )
            seMetas.setOnDataPointTapListener { _, dataPoint ->
                val prompt = Toast.makeText(
                    this,
                    "Goal: ${meta.second}, Progress: ${dataPoint.y.toInt()}%",
                    Toast.LENGTH_SHORT
                )
                prompt.setGravity(Gravity.CENTER_HORIZONTAL, grMetas.x.toInt(), grMetas.y.toInt())
                prompt.show();
            }
            seMetas.color = Color.rgb((i + 1) * 255 / 4, (i + 1) * 255 / 6, (i + 1) * 100)
            grMetas.addSeries(
                seMetas
            )
        }

        grMetas.gridLabelRenderer.gridColor = Color.parseColor("#A9B1C5")
        grMetas.gridLabelRenderer.gridStyle = GridLabelRenderer.GridStyle.HORIZONTAL

        grMetas.viewport.setMinX(0.0);
        grMetas.viewport.setMaxX(6.0);
        grMetas.viewport.isXAxisBoundsManual = true;

        grMetas.viewport.setMinY(-10.0);
        grMetas.viewport.setMaxY(100.0);
        grMetas.viewport.isYAxisBoundsManual = true;

        grMetas.gridLabelRenderer.isHorizontalLabelsVisible = false

        grMetas.gridLabelRenderer.labelFormatter = object : DefaultLabelFormatter() {
            override fun formatLabel(value: Double, isValueX: Boolean): String {
                return if (isValueX) {
                    super.formatLabel(value, isValueX)
                } else {
                    super.formatLabel(value, isValueX) + "%"
                }
            }
        }
    }

    fun crearBarra() {
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        val bar = TopBar()
        val argumentos = Bundle()
        argumentos.putString("titulo", "Dashboard")
        bar.arguments = argumentos

        fragmentTransaction.replace(R.id.rl_topBar, bar)
        fragmentTransaction.commit()
    }

    override fun finish() {
        super.finishAffinity()
        overridePendingTransition(R.anim.slide_down, R.anim.slide_down)
    }
}